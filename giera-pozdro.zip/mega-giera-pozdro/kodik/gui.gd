extends CanvasLayer

var InvSize = 16

# do ogarnięcia pickupy 

# to zr
var itemLoad = [
	"res://itemResources/czast1.tres",
	"res://itemResources/czast2.tres"
]

func _ready() -> void:
	for i in range(InvSize):
		var slot := InventorySlot.new()
		slot.init(ItemData.Type.PIERWSZE, Vector2(40, 40))
		%Inv.add_child(slot)

	for i in itemLoad.size():
		var item := InventoryItem.new()
		item.init(load(itemLoad[i]))
		%Inv.get_child(i).add_child(item)
	
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("eq"):
		self.visible = !self.visible
		
