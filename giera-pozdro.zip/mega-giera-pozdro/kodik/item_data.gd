extends Resource
class_name ItemData

enum Type {PIERWSZE, DRUGIE, TRZECIE, MAIN}

@export var type: Type
@export var nazwa: String
@export_multiline var opis: String
@export var texture: Texture2D
