extends Resource

class_name InvItem

@export var name: String = ""
@export var textute: Texture2D
